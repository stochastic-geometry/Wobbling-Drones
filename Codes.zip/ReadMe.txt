This code generates Figs. 2, 3, and 4 of [1].

Please cite [1] if you reuse any part of this code.

[1] M. Banagar, H. S. Dhillon, and A. F. Molisch, “Impact of UAV wobbling on the air-to-ground wireless channel”, IEEE Transactions on Vehicular Technology, to appear.